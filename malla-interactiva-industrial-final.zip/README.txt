INSTRUCCIONES PARA USAR LA MALLA INTERACTIVA

1. Abre index.html en cualquier navegador.
2. Haz clic sobre un curso para tacharlo como completado.
3. Pasa el cursor para ver detalles del curso.
4. Puedes subir estos 3 archivos a un repositorio en GitHub.
   Luego ve a Settings > Pages y actívalo para ver tu malla online.

Desarrollado para: Alejandra Herrera Palacios
